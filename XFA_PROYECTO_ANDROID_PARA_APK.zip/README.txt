# XFA para Android

Este es un proyecto Android que abre la versión HTML de XFA dentro de una aplicación WebView, sin necesitar internet para cargar la interfaz local.

## Importante
Este ZIP contiene el proyecto fuente, no un APK ya compilado. Para generar el APK hay que compilar el proyecto con Android SDK/Gradle o usar el flujo de GitHub Actions incluido.

## Generar el APK mediante GitHub Actions
1. Sube el contenido de esta carpeta a un repositorio propio de GitHub.
2. Abre la pestaña Actions.
3. Ejecuta el flujo "Build XFA APK" con "Run workflow" (o sube el commit a la rama main).
4. Cuando termine, abre la ejecución y descarga el artefacto `XFA-debug-APK`.
5. Dentro estará `app-debug.apk`, instalable en Android.

## Detalles
- Nombre de la app: XFA
- Paquete: com.xfa.archivero
- Android mínimo: 6.0 (API 23)
- Incluye el HTML como asset local.
- La compilación necesita descargar Gradle y el Android Gradle Plugin.
